opencv_version = "4.5.5.64"
contrib = False
headless = True
ci_build = True